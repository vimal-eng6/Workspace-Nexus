import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { getRooms, getBookings } from '../api/services';
import { SOCKET_URL } from '../api/config';
import { io } from 'socket.io-client';
import Modal from '../components/Modal';
import {
  CalendarDays,
  Clock,
  Users,
  DoorOpen,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Info,
  CalendarCheck,
  Lightbulb,
} from 'lucide-react';


const HOURS = Array.from({ length: 12 }, (_, i) => i + 8); // 8 AM - 7 PM

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [rooms, setRooms] = useState([]);
  const [allBookings, setAllBookings] = useState([]);
  const [selectedDate, setSelectedDate] = useState(() => {
    const d = new Date();
    return d.toISOString().split('T')[0];
  });
  const [locationFilter, setLocationFilter] = useState('All');
  const [loading, setLoading] = useState(true);
  const [detailModal, setDetailModal] = useState(null);

  useEffect(() => {
    loadData();

    // Setup Socket.io for Real-Time Updates
    const socket = io(SOCKET_URL);
    
    socket.on('connect', () => {
      console.log('Connected to realtime socket');
    });
    
    socket.on('refresh_bookings', () => {
      console.log('Refresh trigger received via socket');
      loadData();
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const [roomsData, bookingsData] = await Promise.all([
        getRooms(),
        getBookings(),
      ]);
      setRooms(Array.isArray(roomsData) ? roomsData : []);
      setAllBookings(Array.isArray(bookingsData) ? bookingsData : []);
    } catch (err) {
      console.error('Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSlotClick = (room, hour, slot) => {
    if (!slot.booked) {
      // Navigate to booking page with pre-filled room and time
      const date = selectedDate;
      const start = `${date}T${String(hour).padStart(2, '0')}:00`;
      navigate(`/book?room=${room.id}&start=${start}`);
      return;
    }

    if (!slot.isPrivate) {
      setDetailModal(slot.booking);
    }
  };

  // Client-side date filtering since backend returns all bookings
  const bookings = allBookings.filter((b) => {
    const bookingDate = b.start_time?.split('T')[0] || b.start_time?.split(' ')[0];
    return bookingDate === selectedDate;
  });


  const changeDate = (offset) => {
    const d = new Date(selectedDate);
    d.setDate(d.getDate() + offset);
    setSelectedDate(d.toISOString().split('T')[0]);
  };

  const locations = ['All', ...new Set(rooms.map((r) => r.location || 'Office'))];

  const filteredRooms =
    locationFilter === 'All'
      ? rooms
      : rooms.filter((r) => (r.location || 'Office') === locationFilter);

  const getBookingsForRoom = (roomId) =>
    bookings.filter((b) => b.room_id === roomId || b.room_id === String(roomId));

  const getSlotStatus = (roomId, hour) => {
    const roomBookings = getBookingsForRoom(roomId);
    for (const b of roomBookings) {
      const start = new Date(b.start_time);
      const end = new Date(b.end_time);
      const slotStart = new Date(`${selectedDate}T${String(hour).padStart(2, '0')}:00:00`);
      const slotEnd = new Date(`${selectedDate}T${String(hour + 1).padStart(2, '0')}:00:00`);

      if (slotStart < end && slotEnd > start) {
        // Privacy: if the booking has a division field and it doesn't match the user's division
        const bookingDivision = b.division || null;
        const isOwnDivision = !bookingDivision || bookingDivision === user?.division;
        return {
          booked: true,
          booking: b,
          label: isOwnDivision ? (b.username || 'Booked') : 'Occupied',
          isPrivate: !isOwnDivision,
          isKT: b.is_kt,
          division: bookingDivision,
        };
      }
    }
    return { booked: false };
  };

  const formatDate = (dateStr) => {
    return new Date(dateStr + 'T00:00:00').toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Stats
  const totalRooms = filteredRooms.length;
  const totalBookingsToday = bookings.length;
  const bookedRoomIds = new Set(bookings.map((b) => b.room_id));
  const availableRooms = totalRooms - bookedRoomIds.size;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-desc">
            Welcome back, <strong>{user?.username}</strong> — {user?.division || 'Team'} Division
          </p>
        </div>
        <button className="btn btn--secondary" onClick={loadData}>
          Refresh
        </button>
      </div>

      {/* Stats Cards */}
      <div className="stats-grid">
        <div className="stat-card stat-card--blue">
          <div className="stat-icon"><DoorOpen size={24} /></div>
          <div className="stat-info">
            <span className="stat-value">{totalRooms}</span>
            <span className="stat-label">Total Rooms</span>
          </div>
        </div>
        <div className="stat-card stat-card--green">
          <div className="stat-icon"><CalendarDays size={24} /></div>
          <div className="stat-info">
            <span className="stat-value">{totalBookingsToday}</span>
            <span className="stat-label">Bookings Today</span>
          </div>
        </div>
        <div className="stat-card stat-card--purple">
          <div className="stat-icon"><Clock size={24} /></div>
          <div className="stat-info">
            <span className="stat-value">{availableRooms}</span>
            <span className="stat-label">Available Now</span>
          </div>
        </div>
        <div className="stat-card stat-card--amber">
          <div className="stat-icon"><Users size={24} /></div>
          <div className="stat-info">
            <span className="stat-value">{user?.division || '—'}</span>
            <span className="stat-label">Your Division</span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="dashboard-controls">
        <div className="date-nav">
          <button className="btn btn--icon" onClick={() => changeDate(-1)}>
            <ChevronLeft size={20} />
          </button>
          <div className="date-display">
            <CalendarDays size={18} />
            <span>{formatDate(selectedDate)}</span>
          </div>
          <button className="btn btn--icon" onClick={() => changeDate(1)}>
            <ChevronRight size={20} />
          </button>
          <input
            type="date"
            className="form-input date-picker-inline"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
          />
        </div>

        <div className="location-filter">
          <MapPin size={16} />
          <select
            className="form-input form-select form-select--sm"
            value={locationFilter}
            onChange={(e) => setLocationFilter(e.target.value)}
          >
            {locations.map((loc) => (
              <option key={loc} value={loc}>{loc}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Schedule Grid */}
      {loading ? (
        <div className="loading-state">
          <Loader2 size={32} className="spin" />
          <p>Loading schedule...</p>
        </div>
      ) : filteredRooms.length === 0 ? (
        <div className="empty-state">
          <DoorOpen size={48} />
          <h3>No rooms found</h3>
          <p>There are no rooms available for the selected filter.</p>
        </div>
      ) : (
        <div className="schedule-wrapper">
          <div className="schedule-grid">
            {/* Header row */}
            <div className="schedule-cell schedule-corner">Room</div>
            {HOURS.map((h) => (
              <div key={h} className="schedule-cell schedule-hour-header">
                {h > 12 ? h - 12 : h}{h >= 12 ? 'PM' : 'AM'}
              </div>
            ))}

            {/* Room rows */}
            {filteredRooms.map((room) => (
              <div key={room.id} className="schedule-row-fragment" style={{ display: 'contents' }}>
                <div className="schedule-cell schedule-room-label">
                  <span className="room-name">{room.name || `Room ${room.id}`}</span>
                  <span className="room-meta">
                    {room.capacity && <><Users size={12} /> {room.capacity}</>}
                  </span>
                </div>
                {HOURS.map((h) => {
                  const slot = getSlotStatus(room.id, h);
                  return (
                    <div
                      key={`${room.id}-${h}`}
                      className={`schedule-cell schedule-slot ${
                        slot.booked
                          ? slot.isPrivate
                            ? 'schedule-slot--private'
                            : slot.isKT
                            ? 'schedule-slot--kt'
                            : 'schedule-slot--booked'
                          : 'schedule-slot--free'
                      }`}
                      onClick={() => handleSlotClick(room, h, slot)}
                      style={{ cursor: 'pointer' }}
                    >
                      {slot.booked && (
                        <span className="slot-label">
                          {slot.isPrivate ? '🔒' : slot.label}
                        </span>
                      )}
                    </div>

                  );
                })}
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="schedule-legend">
            <div className="legend-item">
              <span className="legend-dot legend-dot--free"></span> Available
            </div>
            <div className="legend-item">
              <span className="legend-dot legend-dot--booked"></span> Booked
            </div>
            <div className="legend-item">
              <span className="legend-dot legend-dot--private"></span> Private / Occupied
            </div>
            <div className="legend-item">
              <span className="legend-dot legend-dot--kt"></span> KT Session
            </div>
          </div>
        </div>
      )}
      
      {/* Booking Detail Modal */}
      <Modal
        isOpen={!!detailModal}
        onClose={() => setDetailModal(null)}
        title="Booking Details"
      >
        {detailModal && (
          <div className="booking-detail">
             <div className="detail-header">
                <CalendarCheck className="detail-icon" />
                <div className="detail-room-name">
                   {rooms.find(r => r.id === detailModal.room_id || String(r.id) === String(detailModal.room_id))?.name || `Room ${detailModal.room_id}`}
                </div>
             </div>
             
             <div className="detail-grid">
                <div className="detail-item">
                   <Clock size={16} />
                   <span>{new Date(detailModal.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} — {new Date(detailModal.end_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
                <div className="detail-item">
                   <Users size={16} />
                   <span>{detailModal.username} ({detailModal.division})</span>
                </div>
                {detailModal.is_kt ? (
                   <div className="detail-kt-badge">
                      <Lightbulb size={14} />
                      Knowledge Transfer
                   </div>
                ) : null}
             </div>
             
             {detailModal.is_kt && detailModal.kt_topic && (
                <div className="detail-kt-info">
                   <div className="detail-label">KT Topic</div>
                   <div className="detail-val">{detailModal.kt_topic}</div>
                </div>
             )}
             
             {detailModal.is_kt && detailModal.kt_notes && (
                <div className="detail-kt-info">
                   <div className="detail-label">Notes</div>
                   <div className="detail-val">{detailModal.kt_notes}</div>
                </div>
             )}
             
             <button className="btn btn--primary btn--full mt-4" onClick={() => setDetailModal(null)}>
                Close
             </button>
          </div>
        )}
      </Modal>
    </div>
  );
}

