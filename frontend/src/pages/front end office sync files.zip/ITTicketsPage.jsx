import { useState, useEffect } from 'react';
import { getITTickets, updateTicketStatus } from '../api/services';
import StatusBadge from '../components/StatusBadge';
import {
  Headset,
  Loader2,
  CheckCircle2,
  Clock,
  AlertCircle,
  Filter,
  Inbox,
} from 'lucide-react';

export default function ITTicketsPage() {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('All');
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => {
    loadTickets();
  }, []);

  const loadTickets = async () => {
    setLoading(true);
    try {
      const data = await getITTickets();
      setTickets(Array.isArray(data) ? data : data.tickets || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusToggle = async (ticket) => {
    const newStatus = ticket.status === 'Open' ? 'Closed' : 'Open';
    setUpdatingId(ticket.id);
    try {
      await updateTicketStatus(ticket.id, newStatus);
      setTickets((prev) =>
        prev.map((t) => (t.id === ticket.id ? { ...t, status: newStatus } : t))
      );
    } catch (err) {
      alert(err.message);
    } finally {
      setUpdatingId(null);
    }
  };

  const filtered =
    filter === 'All' ? tickets : tickets.filter((t) => t.status === filter);

  const openCount = tickets.filter((t) => t.status === 'Open').length;
  const closedCount = tickets.filter((t) => t.status === 'Closed').length;

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1 className="page-title">
            <Headset size={28} /> IT Support Tickets
          </h1>
          <p className="page-desc">Track and manage room setup requests</p>
        </div>
        <button className="btn btn--secondary" onClick={loadTickets}>
          Refresh
        </button>
      </div>

      {/* Ticket Stats */}
      <div className="ticket-stats">
        <button
          className={`ticket-stat-btn ${filter === 'All' ? 'ticket-stat-btn--active' : ''}`}
          onClick={() => setFilter('All')}
        >
          <Filter size={16} />
          <span>All</span>
          <span className="ticket-stat-count">{tickets.length}</span>
        </button>
        <button
          className={`ticket-stat-btn ticket-stat-btn--open ${filter === 'Open' ? 'ticket-stat-btn--active' : ''}`}
          onClick={() => setFilter('Open')}
        >
          <AlertCircle size={16} />
          <span>Open</span>
          <span className="ticket-stat-count">{openCount}</span>
        </button>
        <button
          className={`ticket-stat-btn ticket-stat-btn--closed ${filter === 'Closed' ? 'ticket-stat-btn--active' : ''}`}
          onClick={() => setFilter('Closed')}
        >
          <CheckCircle2 size={16} />
          <span>Closed</span>
          <span className="ticket-stat-count">{closedCount}</span>
        </button>
      </div>

      {loading ? (
        <div className="loading-state">
          <Loader2 size={32} className="spin" />
          <p>Loading tickets...</p>
        </div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <Inbox size={48} />
          <h3>No tickets found</h3>
          <p>{filter === 'All' ? 'No IT support tickets have been created yet.' : `No ${filter.toLowerCase()} tickets.`}</p>
        </div>
      ) : (
        <div className="tickets-table-wrapper">
          <table className="tickets-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Booking</th>
                <th>Issue Type</th>
                <th>Description</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((ticket) => (
                <tr key={ticket.id} className={`ticket-row ticket-row--${ticket.status?.toLowerCase()}`}>
                  <td className="ticket-id">#{ticket.id}</td>
                  <td>
                    <div className="ticket-booking">
                      <div className="ticket-room-info">
                        <strong>{ticket.room_name}</strong>
                      </div>
                      <div className="ticket-time-info">
                         {new Date(ticket.start_time).toLocaleString('en-US', { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })}
                      </div>
                    </div>
                  </td>
                  <td>
                    <span className="ticket-issue-type">{ticket.issue_type}</span>
                    <div className="ticket-user-info">By: {ticket.booked_by}</div>
                  </td>

                  <td className="ticket-desc-cell">
                    {ticket.description || '—'}
                  </td>
                  <td>
                    <StatusBadge
                      status={ticket.status}
                      variant={ticket.status === 'Open' ? 'warning' : 'success'}
                    />
                  </td>
                  <td>
                    <button
                      className={`btn btn--sm ${ticket.status === 'Open' ? 'btn--primary' : 'btn--ghost'}`}
                      onClick={() => handleStatusToggle(ticket)}
                      disabled={updatingId === ticket.id}
                    >
                      {updatingId === ticket.id ? (
                        <Loader2 size={14} className="spin" />
                      ) : ticket.status === 'Open' ? (
                        <>
                          <CheckCircle2 size={14} /> Resolve
                        </>
                      ) : (
                        <>
                          <Clock size={14} /> Reopen
                        </>
                      )}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
